extern void genPerms(int nElems,
                     void (*handlePerm)(int elems[],
                                        int nElems,
                                        void *userArg),
                     void *userArg);
