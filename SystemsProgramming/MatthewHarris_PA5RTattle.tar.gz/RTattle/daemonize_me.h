extern void daemonizeMe(const char *cmd);
