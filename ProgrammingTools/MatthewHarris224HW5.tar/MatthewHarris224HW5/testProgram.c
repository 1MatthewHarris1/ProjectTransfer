#include "cma.h"

#define MSIZE 1024*16
unsigned char mem[MSIZE];

int main(int argc, char * argv[]) 
{
	int alpha = atoi(argv[1]);
	while(1)
	{
		printf("Attempting to allocate %d\tbytes...\t", alpha);
		unsigned char mem[alpha];
		class_memory(mem, alpha);
		printf("It worked!\n");
		alpha *= 2;
	}

	return 0;
}
