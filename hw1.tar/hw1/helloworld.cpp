#include<iostream>

int main()
{
	std::cout << "\nHello World\n";
	return 0;
}
