/* $Revision: 1.3 $ */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include "snapshot.h"
